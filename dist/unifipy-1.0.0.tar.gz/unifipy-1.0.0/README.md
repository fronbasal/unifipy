# Unifi Python Voucher API

This API contains a Unifi API wrapper specifically for creating vouchers programmatically.
